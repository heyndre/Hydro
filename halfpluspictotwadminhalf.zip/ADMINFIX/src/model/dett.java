/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author pande
 */
public class dett {
    private String idt;
    private String namat;
    private String deskt;

    public String getIdt() {
        return idt;
    }

    public void setIdt(String idt) {
        this.idt = idt;
    }

    public String getNamat() {
        return namat;
    }

    public void setNamat(String namat) {
        this.namat = namat;
    }

    public String getDeskt() {
        return deskt;
    }

    public void setDeskt(String deskt) {
        this.deskt = deskt;
    }
}
