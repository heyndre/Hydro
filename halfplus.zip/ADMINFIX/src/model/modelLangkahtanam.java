/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.InputStream;

/**
 *
 * @author DIKA
 */
public class modelLangkahtanam {
    
    private int id_langkahtanam;
    private String namatanaman, langkahtanam, path;
    private InputStream gambar;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    
    public int getId_langkahtanam() {
        return id_langkahtanam;
    }

    public void setId_langkahtanam(int id_langkahtanam) {
        this.id_langkahtanam = id_langkahtanam;
    }

    public String getNamatanaman() {
        return namatanaman;
    }

    public void setNamatanaman(String namatanaman) {
        this.namatanaman = namatanaman;
    }

    public String getLangkahtanam() {
        return langkahtanam;
    }

    public void setLangkahtanam(String langkahtanam) {
        this.langkahtanam = langkahtanam;
    }

    public InputStream getGambar() {
        return gambar;
    }

    public void setGambar(InputStream gambar) {
        this.gambar = gambar;
    }
   
    
    
}
