/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author pande
 */
public class lt {
    private String idlt;
    private String lt;
    private String idT;
    private String namaT;
    private String path;

    public String getIdlt() {
        return idlt;
    }

    public void setIdlt(String idlt) {
        this.idlt = idlt;
    }

    public String getLt() {
        return lt;
    }

    public void setLt(String lt) {
        this.lt = lt;
    }

    public String getIdT() {
        return idT;
    }

    public void setIdT(String idT) {
        this.idT = idT;
    }

    public String getNamaT() {
        return namaT;
    }

    public void setNamaT(String namaT) {
        this.namaT = namaT;
    }
}
