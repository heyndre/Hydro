/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author pande
 */
public class daftarTanaman {
    int IDT;
    String NamaTanaman;
    String Desk;

    public int getIDT() {
        return IDT;
    }

    public void setIDT(int IDT) {
        this.IDT = IDT;
    }

    public String getNamaTanaman() {
        return NamaTanaman;
    }

    public void setNamaTanaman(String NamaTanaman) {
        this.NamaTanaman = NamaTanaman;
    }

    public String getDesk() {
        return Desk;
    }

    public void setDesk(String Desk) {
        this.Desk = Desk;
    }
}
