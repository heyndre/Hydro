/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author DIKA
 */
public class modelPerawatan {
    private int id_langkahtanam, id_perawatan;
    private String perawtan;

    public int getId_langkahtanam() {
        return id_langkahtanam;
    }

    public void setId_langkahtanam(int id_langkahtanam) {
        this.id_langkahtanam = id_langkahtanam;
    }

    public int getId_perawatan() {
        return id_perawatan;
    }

    public void setId_perawatan(int id_perawatan) {
        this.id_perawatan = id_perawatan;
    }

    public String getPerawtan() {
        return perawtan;
    }

    public void setPerawtan(String perawtan) {
        this.perawtan = perawtan;
    }
    
    
}
