/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class koneksi {
        private static final String url = "jdbc:mysql://localhost:3306/pbohydro?serverTimezone=UTC";
    private static final String user = "root";
    private static final String password = "";
//    private static Connection koneksi=null;

//    public static Connection getKoneksi() {
////        if (koneksi == null) {
//            try {
//                String url, user, password;
//                url = "jdbc:postgresql://localhost:5432/hydro";
//                user = "postgres";
//                password = "root";
//                koneksi = DriverManager.getConnection("jdbc:postgresql://localhost/hydro", "postgres", "root");
//                
//                System.out.println("Koneksi Berhasil");
//            } catch (SQLException e) {
//                System.out.println("Koneksi Gagal");
//            }
////        }
//        return koneksi;
//    }
        public static Connection connect() {
                Connection conn = null;
                try {
                    conn = DriverManager.getConnection(url, user, password);
                    System.out.println("Connected to the MySQL server successfully.");
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
 
        return conn;
    }
    
    public static void main(String[] args) {
                koneksi app = new koneksi();
        app.connect();
//        koneksi app = new koneksi();
//        app.getKoneksi();
//    getKoneksi();
    }
}
