/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Andre
 */
public class connection {
    private final String url = "jdbc:mysql://localhost:3306/pbohydro?serverTimezone=UTC";
    private final String user = "root";
    private final String password = "";
 
    /**
     * Connect to the PostgreSQL database
     *
     * @return a Connection object
     */
    public Connection connect() {
                Connection conn = null;
                try {
                    conn = DriverManager.getConnection(url, user, password);
                    System.out.println("Connected to the server successfully.");
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
 
        return conn;
    }
        public static void main(String[] args) {
        connection app = new connection();
        app.connect();
    }
}
